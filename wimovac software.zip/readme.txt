
Run WIMOVAC:

(for Windows)
Double click WIMOVAC.bat.

(for Linux and Mac)
java -jar WIMOVAC1.0.jar.


OUTPUT File:

WIMOVAC_OutputFile_Leaf.csv is leaf model output file
WIMOVAC_OutputFile_CanopyAssimilation.csv is canopy output file
WIMOVAC_OutputFile_CanopyMicroclimate.csv is canopy microclimate output file
WIMOVAC_OutputFile_Plant.csv is plant growth model output file

