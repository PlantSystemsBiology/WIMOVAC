java -jar WIMOVAC1.2.jar
