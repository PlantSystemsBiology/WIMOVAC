
Quick Start for Windows PC: double click wimovac.exe


############################
For Windows platform: 

double click wimovac.exe

OR 

use commandline to run "java -jar WIMOVAC1.2.jar"

############################


#########################################
For Mac OS and Linux platform: 

double click wimovac.sh 

OR

use commandline to run "sh wimovac.sh"

OR

use commandline to run "java -jar WIMOVAC1.2.jar"

#########################################
