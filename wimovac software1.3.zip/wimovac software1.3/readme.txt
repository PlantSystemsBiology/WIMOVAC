

For Windows

Double click WIMOVAC1.3.jar 

or Double click Run_WIMOVAC.bat



For Linux or Mac OS.

commandline to run:

java -jar WIMOVAC1.3.jar

